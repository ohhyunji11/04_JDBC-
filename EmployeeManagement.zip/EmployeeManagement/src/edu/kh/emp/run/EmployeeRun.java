package edu.kh.emp.run;

public class EmployeeRun {
	public static void main(String[] args) {
		
	}
}
