package edu.kh.jdbc.main.run;

import edu.kh.jdbc.main.view.MainView;

public class MainRun {
	public static void main(String[] args) {
		
		// MainView의 mainMenu 호출
		new MainView().mainMenu();
	}
}
