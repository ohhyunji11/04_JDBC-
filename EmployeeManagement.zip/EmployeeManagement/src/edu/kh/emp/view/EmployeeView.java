package edu.kh.emp.view;

public class EmployeeView {

}
